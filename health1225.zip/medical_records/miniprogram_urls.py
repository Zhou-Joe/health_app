from django.urls import path
from . import miniprogram_api

app_name = 'miniprogram'

urlpatterns = [
    # 用户认证
    path('login/', miniprogram_api.miniprogram_login, name='login'),
    path('user-info/', miniprogram_api.miniprogram_user_info, name='user_info'),

    # 体检报告管理
    path('upload/', miniprogram_api.miniprogram_upload_report, name='upload_report'),
    path('processing-status/<int:processing_id>/', miniprogram_api.miniprogram_processing_status, name='processing_status'),

    # 体检记录查询
    path('checkups/', miniprogram_api.miniprogram_checkup_list, name='checkup_list'),
    path('checkups/<int:checkup_id>/', miniprogram_api.miniprogram_checkup_detail, name='checkup_detail'),

    # 健康指标
    path('indicators/', miniprogram_api.miniprogram_indicators, name='indicators'),
    path('checkups/<int:checkup_id>/indicators/', miniprogram_api.miniprogram_indicators, name='checkup_indicators'),

    # AI建议
    path('advice/', miniprogram_api.miniprogram_get_advice, name='get_advice'),

    # 系统状态和设置
    path('services-status/', miniprogram_api.miniprogram_services_status, name='services_status'),
    path('system-settings/', miniprogram_api.miniprogram_system_settings, name='system_settings'),
]